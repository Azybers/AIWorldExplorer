const imageInput = document.getElementById('imageInput');
const chooseButton = document.getElementById('chooseButton');
const previewSection = document.getElementById('previewSection');
const imagePreview = document.getElementById('imagePreview');
const clearPreview = document.getElementById('clearPreview');
const saveButton = document.getElementById('saveButton');
const notesInput = document.getElementById('notes');
const collectionGrid = document.getElementById('collectionGrid');
const collectionCount = document.getElementById('collectionCount');
const emptyState = document.getElementById('emptyState');
const languageSelect = document.getElementById('language');
const accountDialog = document.getElementById('accountDialog');

let currentPhotoData = null;
let currentFileName = '';
let collection = loadCollection();

function loadCollection() {
  try { return JSON.parse(localStorage.getItem('awe-collection') || '[]'); }
  catch { return []; }
}
function persistCollection() {
  try {
    localStorage.setItem('awe-collection', JSON.stringify(collection));
    return true;
  } catch (error) {
    alert(languageSelect.value === 'fil'
      ? 'Hindi na-save ang larawan. Maaaring puno na ang browser storage. Subukan ang mas maliit na larawan.'
      : 'The picture could not be saved. Browser storage may be full. Try a smaller image.');
    return false;
  }
}
function t(en, fil) { return languageSelect.value === 'fil' ? fil : en; }

chooseButton.addEventListener('click', () => imageInput.click());
imageInput.addEventListener('change', () => {
  const file = imageInput.files && imageInput.files[0];
  if (!file) return;
  if (!file.type.startsWith('image/')) {
    alert(t('Please choose an image file.', 'Pumili ng image file.'));
    return;
  }
  // Compress images so browser-only collection storage is less likely to fill up.
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const maxSide = 1200;
      const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
      currentPhotoData = canvas.toDataURL('image/jpeg', 0.78);
      currentFileName = file.name;
      imagePreview.src = currentPhotoData;
      imagePreview.alt = t('Selected picture: ', 'Napiling larawan: ') + file.name;
      previewSection.classList.remove('hidden');
      notesInput.value = '';
      previewSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };
    img.onerror = () => alert(t('This image could not be opened.', 'Hindi mabuksan ang larawang ito.'));
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
});

clearPreview.addEventListener('click', clearCurrentPhoto);
function clearCurrentPhoto() {
  currentPhotoData = null;
  currentFileName = '';
  imageInput.value = '';
  imagePreview.removeAttribute('src');
  previewSection.classList.add('hidden');
  notesInput.value = '';
}

saveButton.addEventListener('click', () => {
  if (!currentPhotoData) return;
  const item = {
    id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random())),
    photo: currentPhotoData,
    fileName: currentFileName || t('Untitled picture', 'Larawang walang pamagat'),
    notes: notesInput.value.trim(),
    savedAt: new Date().toISOString()
  };
  collection.unshift(item);
  if (persistCollection()) {
    renderCollection();
    clearCurrentPhoto();
    document.getElementById('collection').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } else {
    collection.shift();
  }
});

function renderCollection() {
  collectionGrid.innerHTML = '';
  collectionCount.textContent = `${collection.length} ${t('items', 'na item')}`;
  if (!collection.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.innerHTML = `<span aria-hidden="true">▧</span><h3>${t('Your discoveries will live here', 'Dito makikita ang iyong mga tuklas')}</h3><p>${t('Choose a picture above, then save it to start your collection.', 'Pumili ng larawan sa itaas at i-save ito para simulan ang iyong koleksyon.')}</p>`;
    collectionGrid.appendChild(empty);
    return;
  }
  collection.forEach(item => {
    const card = document.createElement('article');
    card.className = 'collection-card';
    const img = document.createElement('img');
    img.src = item.photo;
    img.alt = item.fileName || t('Saved picture', 'Naka-save na larawan');
    const body = document.createElement('div');
    body.className = 'card-body';
    const title = document.createElement('div');
    title.className = 'card-title';
    title.textContent = item.fileName || t('Saved picture', 'Naka-save na larawan');
    const meta = document.createElement('div');
    meta.className = 'card-meta';
    meta.textContent = new Date(item.savedAt).toLocaleDateString(languageSelect.value === 'fil' ? 'fil-PH' : 'en-US', { year: 'numeric', month: 'short', day: 'numeric' });
    body.append(title, meta);
    if (item.notes) {
      const notes = document.createElement('div');
      notes.className = 'card-notes';
      notes.textContent = item.notes;
      body.appendChild(notes);
    }
    const actions = document.createElement('div');
    actions.className = 'card-actions';
    const del = document.createElement('button');
    del.className = 'delete-button';
    del.type = 'button';
    del.textContent = t('Remove', 'Alisin');
    del.addEventListener('click', () => {
      if (!confirm(t('Remove this picture from your collection?', 'Alisin ang larawang ito sa koleksyon mo?'))) return;
      collection = collection.filter(entry => entry.id !== item.id);
      persistCollection();
      renderCollection();
    });
    actions.appendChild(del);
    card.append(img, body, actions);
    collectionGrid.appendChild(card);
  });
}

languageSelect.addEventListener('change', () => {
  document.documentElement.lang = languageSelect.value === 'fil' ? 'fil' : 'en';
  document.querySelectorAll('[data-en][data-fil]').forEach(el => {
    el.textContent = el.dataset[languageSelect.value];
  });
  renderCollection();
});

document.getElementById('accountButton').addEventListener('click', () => accountDialog.showModal());
renderCollection();

if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  window.addEventListener('load', () => navigator.serviceWorker.register('./service-worker.js').catch(() => {}));
}
